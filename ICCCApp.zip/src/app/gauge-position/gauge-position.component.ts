import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gauge-position',
  templateUrl: './gauge-position.component.html',
  styleUrls: ['./gauge-position.component.css']
})
export class GaugePositionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
