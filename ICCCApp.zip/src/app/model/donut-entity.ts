export class DonutEntity {
    count:number;
    color:string;
}
