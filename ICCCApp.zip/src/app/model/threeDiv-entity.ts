export class ThreeDivEntity{
    "Name":String
    "Name2":String
    "color":String

                "Value":number
                "NodeId":number
                "MenuId":number
}

