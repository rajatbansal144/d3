import {DonutEntity} from '../model/donut-entity'
export class SpEntity {

    firstDonutData:DonutEntity[];
    secondDonutData:DonutEntity[];
    spiIndex:string;
    indexValue:string;
    tasks:number;
    missedTasks:number;
}
