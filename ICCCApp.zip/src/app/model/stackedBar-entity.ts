export class StackedBarEntity{
    
        "High":number
        "Mid":number
        "Low":number
        "NodeId":number
        "MenuId":number
      
}