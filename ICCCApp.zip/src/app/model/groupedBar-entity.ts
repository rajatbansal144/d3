export class GroupedBarEntity {
    "model_name": String
    "field1":number
    "field2":number
    "NodeId":number
    "MenuId":number
}