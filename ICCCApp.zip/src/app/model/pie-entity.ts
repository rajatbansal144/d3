export class PieEntity {
    "Id":number
    "Title":string
    "name":string
    "count":number
    "color":string
    "NodeId":number
    "MenuId":number
    }

