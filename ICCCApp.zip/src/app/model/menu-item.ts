export class MenuItem {
    Id:number;
    Text:string;
    IsSelected:boolean=false;
}
