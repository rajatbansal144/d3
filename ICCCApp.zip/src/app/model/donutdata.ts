export class donutdata {
   
    count:number;
    // percentage:number;
    color:string
}
// {name: 'cats', count: 15, percentage: 50, color: 'yellow'},
// {name: 'dogs', count: 10, percentage: 50, color: '#D5CFC8'},
