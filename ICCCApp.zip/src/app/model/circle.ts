export class Circle {
    text: string;
    id: number;
    children: Circle[];
}
