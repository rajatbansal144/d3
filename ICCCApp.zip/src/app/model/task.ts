export class Task {
    Id:number;
    Title:string;
    Description:string;
    IsCompleted:boolean;
    ActualCost:number;
    PlannedCost:number;
    NodeId:number;
    MenuId:number;
}
