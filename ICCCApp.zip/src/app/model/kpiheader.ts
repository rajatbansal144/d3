export class Kpiheader {  
   
    name:string
    type:string
}