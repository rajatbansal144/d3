export class Node {
  text: string;
  id: number;
  children: Node[];
}
