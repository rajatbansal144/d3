export class HalfPieEntity {
    
    "label":string
    "value":number
    "color":string
    "NodeId":number
    "MenuId":number
    "count": number
    }
	