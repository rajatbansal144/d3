export class Base {
    IsValid?:boolean;
    CreationDate?:Date;
    ModificationDate?:Date;
    CreatedBy?:string;
    ModifiedBy?:string;
}
