export class NodeEntity {
    text: string;
    id: number;
    children: NodeEntity[];
    isRoot:boolean=false;
}
